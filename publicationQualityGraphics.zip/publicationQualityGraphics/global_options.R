cch <- FALSE
tdy <- TRUE